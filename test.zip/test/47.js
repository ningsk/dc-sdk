/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


//当前版本  2020年10月1日 - 至今
exports.version = "2.2.0";
//发布时间
exports.update = "2020-11-7 17:35:55";

/***/ }),
