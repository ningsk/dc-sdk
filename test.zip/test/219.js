/* 219 */
/***/ (function(module, exports) {

module.exports = "varying vec3 v_positionEC;\nvarying vec3 v_normalEC;\nvarying vec2 v_st;\nvoid main(){\n    gl_FragColor = xh_getMaterial(v_st);\n}"

/***/ }),